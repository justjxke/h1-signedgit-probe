#!/bin/sh
id
